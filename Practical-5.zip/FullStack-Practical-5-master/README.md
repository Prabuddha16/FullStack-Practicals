# FullStack-Practical-5
Create a Web-Page showing the use of Image-Map in the Web Application.
