# FullStack-Practical-6
Create a Card Layout using CSS layout properties.
