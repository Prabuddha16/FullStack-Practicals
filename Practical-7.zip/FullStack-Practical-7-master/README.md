# FullStack-Practical-7
Create a Web Page Layout using div tags.
