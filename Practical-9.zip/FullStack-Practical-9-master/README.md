# FullStack-Practical-9
Make a Responsive Web Page
