![Screenshot (133)](https://user-images.githubusercontent.com/63943167/132137255-902aa676-93a6-4e0b-b483-ebcc72363d6a.png)
![Screenshot (129)](https://user-images.githubusercontent.com/63943167/132137266-ba943782-08e6-41e1-a23d-34db29e488b9.png)
![Screenshot (130)](https://user-images.githubusercontent.com/63943167/132137268-c54295bb-8794-4d8c-957f-24ca8f20c285.png)
![Screenshot (131)](https://user-images.githubusercontent.com/63943167/132137269-37c387cd-ca96-497f-96e4-78c1f11591c0.png)
![Screenshot (132)](https://user-images.githubusercontent.com/63943167/132137225-966be520-f5e5-4d3e-a2e5-216dd95505c0.png)
# FullStack-Practical-8
Create a Web Page having Fixed Navigation Bar with the given content.
